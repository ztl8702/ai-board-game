#!/bin/sh

docker build -t ztl8702/wyb:latest --file=./deploy/wyb/Dockerfile .