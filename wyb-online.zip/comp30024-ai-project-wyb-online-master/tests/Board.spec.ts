import {Board} from "../src/logic"

// fromMatrix toMatrix

// shrink board elimination correctness

// something